// Generated from /Users/amiraliataei/Documents/Amirali/Term 5/Compiler/CA/1/src/main/grammar/P1_810197633_810197657.g4 by ANTLR 4.8
package main.grammar;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link P1_810197633_810197657Parser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface P1_810197633_810197657Visitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#s}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS(P1_810197633_810197657Parser.SContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(P1_810197633_810197657Parser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#class_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_(P1_810197633_810197657Parser.Class_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#classDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClassDec(P1_810197633_810197657Parser.ClassDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#classScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClassScope(P1_810197633_810197657Parser.ClassScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#method}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod(P1_810197633_810197657Parser.MethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment(P1_810197633_810197657Parser.AssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#listIndex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListIndex(P1_810197633_810197657Parser.ListIndexContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#index}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex(P1_810197633_810197657Parser.IndexContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(P1_810197633_810197657Parser.ExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#scope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScope(P1_810197633_810197657Parser.ScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#print_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrint_(P1_810197633_810197657Parser.Print_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBody(P1_810197633_810197657Parser.BodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#singleScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingleScope(P1_810197633_810197657Parser.SingleScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#return_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturn_(P1_810197633_810197657Parser.Return_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#if_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf_(P1_810197633_810197657Parser.If_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#else_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElse_(P1_810197633_810197657Parser.Else_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#elseRest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseRest(P1_810197633_810197657Parser.ElseRestContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#parent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParent(P1_810197633_810197657Parser.ParentContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#varDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarDec(P1_810197633_810197657Parser.VarDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#methodDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodDec(P1_810197633_810197657Parser.MethodDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#methodType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodType(P1_810197633_810197657Parser.MethodTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#inputs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInputs(P1_810197633_810197657Parser.InputsContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#argumentDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumentDec(P1_810197633_810197657Parser.ArgumentDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#multiArgDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiArgDec(P1_810197633_810197657Parser.MultiArgDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#multiVarDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiVarDec(P1_810197633_810197657Parser.MultiVarDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#foreach_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForeach_(P1_810197633_810197657Parser.Foreach_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#foreachDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForeachDec(P1_810197633_810197657Parser.ForeachDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#nameOrList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameOrList(P1_810197633_810197657Parser.NameOrListContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList(P1_810197633_810197657Parser.ListContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#member}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMember(P1_810197633_810197657Parser.MemberContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#multiMember}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiMember(P1_810197633_810197657Parser.MultiMemberContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#assignment_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment_(P1_810197633_810197657Parser.Assignment_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#boolExpression_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolExpression_(P1_810197633_810197657Parser.BoolExpression_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#for_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_(P1_810197633_810197657Parser.For_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#forDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForDec(P1_810197633_810197657Parser.ForDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#varType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarType(P1_810197633_810197657Parser.VarTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#multiType_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiType_(P1_810197633_810197657Parser.MultiType_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#type_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_(P1_810197633_810197657Parser.Type_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#ifDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfDec(P1_810197633_810197657Parser.IfDecContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(P1_810197633_810197657Parser.TypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#comment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComment(P1_810197633_810197657Parser.CommentContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#methodCall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodCall(P1_810197633_810197657Parser.MethodCallContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#chain}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChain(P1_810197633_810197657Parser.ChainContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#methodInput}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodInput(P1_810197633_810197657Parser.MethodInputContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#multiTerm}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiTerm(P1_810197633_810197657Parser.MultiTermContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#not}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNot(P1_810197633_810197657Parser.NotContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#mathExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMathExpression(P1_810197633_810197657Parser.MathExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#t}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitT(P1_810197633_810197657Parser.TContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtom(P1_810197633_810197657Parser.AtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#boolExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolExpression(P1_810197633_810197657Parser.BoolExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#b}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitB(P1_810197633_810197657Parser.BContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#b_}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitB_(P1_810197633_810197657Parser.B_Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#b__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitB__(P1_810197633_810197657Parser.B__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#b___}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitB___(P1_810197633_810197657Parser.B___Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#back}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBack(P1_810197633_810197657Parser.BackContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#front}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFront(P1_810197633_810197657Parser.FrontContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#mathTerm}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMathTerm(P1_810197633_810197657Parser.MathTermContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#boolTerm}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolTerm(P1_810197633_810197657Parser.BoolTermContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTerm(P1_810197633_810197657Parser.TermContext ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#return__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturn__(P1_810197633_810197657Parser.Return__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#continue__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinue__(P1_810197633_810197657Parser.Continue__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#break__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreak__(P1_810197633_810197657Parser.Break__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#print__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrint__(P1_810197633_810197657Parser.Print__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#func__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc__(P1_810197633_810197657Parser.Func__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#new__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNew__(P1_810197633_810197657Parser.New__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#class__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass__(P1_810197633_810197657Parser.Class__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#for__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor__(P1_810197633_810197657Parser.For__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#foreach__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForeach__(P1_810197633_810197657Parser.Foreach__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#def__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDef__(P1_810197633_810197657Parser.Def__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#else__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElse__(P1_810197633_810197657Parser.Else__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#in__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn__(P1_810197633_810197657Parser.In__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#list__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList__(P1_810197633_810197657Parser.List__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#if__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf__(P1_810197633_810197657Parser.If__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#int__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInt__(P1_810197633_810197657Parser.Int__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#string__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString__(P1_810197633_810197657Parser.String__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#void__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVoid__(P1_810197633_810197657Parser.Void__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#bool__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBool__(P1_810197633_810197657Parser.Bool__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#extends__}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExtends__(P1_810197633_810197657Parser.Extends__Context ctx);
	/**
	 * Visit a parse tree produced by {@link P1_810197633_810197657Parser#name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitName(P1_810197633_810197657Parser.NameContext ctx);
}