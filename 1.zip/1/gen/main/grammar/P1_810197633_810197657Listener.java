// Generated from /Users/amiraliataei/Documents/Amirali/Term 5/Compiler/CA/1/src/main/grammar/P1_810197633_810197657.g4 by ANTLR 4.8
package main.grammar;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link P1_810197633_810197657Parser}.
 */
public interface P1_810197633_810197657Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#s}.
	 * @param ctx the parse tree
	 */
	void enterS(P1_810197633_810197657Parser.SContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#s}.
	 * @param ctx the parse tree
	 */
	void exitS(P1_810197633_810197657Parser.SContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(P1_810197633_810197657Parser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(P1_810197633_810197657Parser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#class_}.
	 * @param ctx the parse tree
	 */
	void enterClass_(P1_810197633_810197657Parser.Class_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#class_}.
	 * @param ctx the parse tree
	 */
	void exitClass_(P1_810197633_810197657Parser.Class_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#classDec}.
	 * @param ctx the parse tree
	 */
	void enterClassDec(P1_810197633_810197657Parser.ClassDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#classDec}.
	 * @param ctx the parse tree
	 */
	void exitClassDec(P1_810197633_810197657Parser.ClassDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#classScope}.
	 * @param ctx the parse tree
	 */
	void enterClassScope(P1_810197633_810197657Parser.ClassScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#classScope}.
	 * @param ctx the parse tree
	 */
	void exitClassScope(P1_810197633_810197657Parser.ClassScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#method}.
	 * @param ctx the parse tree
	 */
	void enterMethod(P1_810197633_810197657Parser.MethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#method}.
	 * @param ctx the parse tree
	 */
	void exitMethod(P1_810197633_810197657Parser.MethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(P1_810197633_810197657Parser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(P1_810197633_810197657Parser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#listIndex}.
	 * @param ctx the parse tree
	 */
	void enterListIndex(P1_810197633_810197657Parser.ListIndexContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#listIndex}.
	 * @param ctx the parse tree
	 */
	void exitListIndex(P1_810197633_810197657Parser.ListIndexContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#index}.
	 * @param ctx the parse tree
	 */
	void enterIndex(P1_810197633_810197657Parser.IndexContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#index}.
	 * @param ctx the parse tree
	 */
	void exitIndex(P1_810197633_810197657Parser.IndexContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(P1_810197633_810197657Parser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(P1_810197633_810197657Parser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#scope}.
	 * @param ctx the parse tree
	 */
	void enterScope(P1_810197633_810197657Parser.ScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#scope}.
	 * @param ctx the parse tree
	 */
	void exitScope(P1_810197633_810197657Parser.ScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#print_}.
	 * @param ctx the parse tree
	 */
	void enterPrint_(P1_810197633_810197657Parser.Print_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#print_}.
	 * @param ctx the parse tree
	 */
	void exitPrint_(P1_810197633_810197657Parser.Print_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(P1_810197633_810197657Parser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(P1_810197633_810197657Parser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#singleScope}.
	 * @param ctx the parse tree
	 */
	void enterSingleScope(P1_810197633_810197657Parser.SingleScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#singleScope}.
	 * @param ctx the parse tree
	 */
	void exitSingleScope(P1_810197633_810197657Parser.SingleScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#return_}.
	 * @param ctx the parse tree
	 */
	void enterReturn_(P1_810197633_810197657Parser.Return_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#return_}.
	 * @param ctx the parse tree
	 */
	void exitReturn_(P1_810197633_810197657Parser.Return_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#if_}.
	 * @param ctx the parse tree
	 */
	void enterIf_(P1_810197633_810197657Parser.If_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#if_}.
	 * @param ctx the parse tree
	 */
	void exitIf_(P1_810197633_810197657Parser.If_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#else_}.
	 * @param ctx the parse tree
	 */
	void enterElse_(P1_810197633_810197657Parser.Else_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#else_}.
	 * @param ctx the parse tree
	 */
	void exitElse_(P1_810197633_810197657Parser.Else_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#elseRest}.
	 * @param ctx the parse tree
	 */
	void enterElseRest(P1_810197633_810197657Parser.ElseRestContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#elseRest}.
	 * @param ctx the parse tree
	 */
	void exitElseRest(P1_810197633_810197657Parser.ElseRestContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#parent}.
	 * @param ctx the parse tree
	 */
	void enterParent(P1_810197633_810197657Parser.ParentContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#parent}.
	 * @param ctx the parse tree
	 */
	void exitParent(P1_810197633_810197657Parser.ParentContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#varDec}.
	 * @param ctx the parse tree
	 */
	void enterVarDec(P1_810197633_810197657Parser.VarDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#varDec}.
	 * @param ctx the parse tree
	 */
	void exitVarDec(P1_810197633_810197657Parser.VarDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#methodDec}.
	 * @param ctx the parse tree
	 */
	void enterMethodDec(P1_810197633_810197657Parser.MethodDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#methodDec}.
	 * @param ctx the parse tree
	 */
	void exitMethodDec(P1_810197633_810197657Parser.MethodDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#methodType}.
	 * @param ctx the parse tree
	 */
	void enterMethodType(P1_810197633_810197657Parser.MethodTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#methodType}.
	 * @param ctx the parse tree
	 */
	void exitMethodType(P1_810197633_810197657Parser.MethodTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#inputs}.
	 * @param ctx the parse tree
	 */
	void enterInputs(P1_810197633_810197657Parser.InputsContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#inputs}.
	 * @param ctx the parse tree
	 */
	void exitInputs(P1_810197633_810197657Parser.InputsContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#argumentDec}.
	 * @param ctx the parse tree
	 */
	void enterArgumentDec(P1_810197633_810197657Parser.ArgumentDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#argumentDec}.
	 * @param ctx the parse tree
	 */
	void exitArgumentDec(P1_810197633_810197657Parser.ArgumentDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#multiArgDec}.
	 * @param ctx the parse tree
	 */
	void enterMultiArgDec(P1_810197633_810197657Parser.MultiArgDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#multiArgDec}.
	 * @param ctx the parse tree
	 */
	void exitMultiArgDec(P1_810197633_810197657Parser.MultiArgDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#multiVarDec}.
	 * @param ctx the parse tree
	 */
	void enterMultiVarDec(P1_810197633_810197657Parser.MultiVarDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#multiVarDec}.
	 * @param ctx the parse tree
	 */
	void exitMultiVarDec(P1_810197633_810197657Parser.MultiVarDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#foreach_}.
	 * @param ctx the parse tree
	 */
	void enterForeach_(P1_810197633_810197657Parser.Foreach_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#foreach_}.
	 * @param ctx the parse tree
	 */
	void exitForeach_(P1_810197633_810197657Parser.Foreach_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#foreachDec}.
	 * @param ctx the parse tree
	 */
	void enterForeachDec(P1_810197633_810197657Parser.ForeachDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#foreachDec}.
	 * @param ctx the parse tree
	 */
	void exitForeachDec(P1_810197633_810197657Parser.ForeachDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#nameOrList}.
	 * @param ctx the parse tree
	 */
	void enterNameOrList(P1_810197633_810197657Parser.NameOrListContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#nameOrList}.
	 * @param ctx the parse tree
	 */
	void exitNameOrList(P1_810197633_810197657Parser.NameOrListContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(P1_810197633_810197657Parser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(P1_810197633_810197657Parser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#member}.
	 * @param ctx the parse tree
	 */
	void enterMember(P1_810197633_810197657Parser.MemberContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#member}.
	 * @param ctx the parse tree
	 */
	void exitMember(P1_810197633_810197657Parser.MemberContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#multiMember}.
	 * @param ctx the parse tree
	 */
	void enterMultiMember(P1_810197633_810197657Parser.MultiMemberContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#multiMember}.
	 * @param ctx the parse tree
	 */
	void exitMultiMember(P1_810197633_810197657Parser.MultiMemberContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#assignment_}.
	 * @param ctx the parse tree
	 */
	void enterAssignment_(P1_810197633_810197657Parser.Assignment_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#assignment_}.
	 * @param ctx the parse tree
	 */
	void exitAssignment_(P1_810197633_810197657Parser.Assignment_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#boolExpression_}.
	 * @param ctx the parse tree
	 */
	void enterBoolExpression_(P1_810197633_810197657Parser.BoolExpression_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#boolExpression_}.
	 * @param ctx the parse tree
	 */
	void exitBoolExpression_(P1_810197633_810197657Parser.BoolExpression_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#for_}.
	 * @param ctx the parse tree
	 */
	void enterFor_(P1_810197633_810197657Parser.For_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#for_}.
	 * @param ctx the parse tree
	 */
	void exitFor_(P1_810197633_810197657Parser.For_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#forDec}.
	 * @param ctx the parse tree
	 */
	void enterForDec(P1_810197633_810197657Parser.ForDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#forDec}.
	 * @param ctx the parse tree
	 */
	void exitForDec(P1_810197633_810197657Parser.ForDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#varType}.
	 * @param ctx the parse tree
	 */
	void enterVarType(P1_810197633_810197657Parser.VarTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#varType}.
	 * @param ctx the parse tree
	 */
	void exitVarType(P1_810197633_810197657Parser.VarTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#multiType_}.
	 * @param ctx the parse tree
	 */
	void enterMultiType_(P1_810197633_810197657Parser.MultiType_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#multiType_}.
	 * @param ctx the parse tree
	 */
	void exitMultiType_(P1_810197633_810197657Parser.MultiType_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#type_}.
	 * @param ctx the parse tree
	 */
	void enterType_(P1_810197633_810197657Parser.Type_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#type_}.
	 * @param ctx the parse tree
	 */
	void exitType_(P1_810197633_810197657Parser.Type_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#ifDec}.
	 * @param ctx the parse tree
	 */
	void enterIfDec(P1_810197633_810197657Parser.IfDecContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#ifDec}.
	 * @param ctx the parse tree
	 */
	void exitIfDec(P1_810197633_810197657Parser.IfDecContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(P1_810197633_810197657Parser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(P1_810197633_810197657Parser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#comment}.
	 * @param ctx the parse tree
	 */
	void enterComment(P1_810197633_810197657Parser.CommentContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#comment}.
	 * @param ctx the parse tree
	 */
	void exitComment(P1_810197633_810197657Parser.CommentContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#methodCall}.
	 * @param ctx the parse tree
	 */
	void enterMethodCall(P1_810197633_810197657Parser.MethodCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#methodCall}.
	 * @param ctx the parse tree
	 */
	void exitMethodCall(P1_810197633_810197657Parser.MethodCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#chain}.
	 * @param ctx the parse tree
	 */
	void enterChain(P1_810197633_810197657Parser.ChainContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#chain}.
	 * @param ctx the parse tree
	 */
	void exitChain(P1_810197633_810197657Parser.ChainContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#methodInput}.
	 * @param ctx the parse tree
	 */
	void enterMethodInput(P1_810197633_810197657Parser.MethodInputContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#methodInput}.
	 * @param ctx the parse tree
	 */
	void exitMethodInput(P1_810197633_810197657Parser.MethodInputContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#multiTerm}.
	 * @param ctx the parse tree
	 */
	void enterMultiTerm(P1_810197633_810197657Parser.MultiTermContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#multiTerm}.
	 * @param ctx the parse tree
	 */
	void exitMultiTerm(P1_810197633_810197657Parser.MultiTermContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#not}.
	 * @param ctx the parse tree
	 */
	void enterNot(P1_810197633_810197657Parser.NotContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#not}.
	 * @param ctx the parse tree
	 */
	void exitNot(P1_810197633_810197657Parser.NotContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#mathExpression}.
	 * @param ctx the parse tree
	 */
	void enterMathExpression(P1_810197633_810197657Parser.MathExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#mathExpression}.
	 * @param ctx the parse tree
	 */
	void exitMathExpression(P1_810197633_810197657Parser.MathExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#t}.
	 * @param ctx the parse tree
	 */
	void enterT(P1_810197633_810197657Parser.TContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#t}.
	 * @param ctx the parse tree
	 */
	void exitT(P1_810197633_810197657Parser.TContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#atom}.
	 * @param ctx the parse tree
	 */
	void enterAtom(P1_810197633_810197657Parser.AtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#atom}.
	 * @param ctx the parse tree
	 */
	void exitAtom(P1_810197633_810197657Parser.AtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#boolExpression}.
	 * @param ctx the parse tree
	 */
	void enterBoolExpression(P1_810197633_810197657Parser.BoolExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#boolExpression}.
	 * @param ctx the parse tree
	 */
	void exitBoolExpression(P1_810197633_810197657Parser.BoolExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#b}.
	 * @param ctx the parse tree
	 */
	void enterB(P1_810197633_810197657Parser.BContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#b}.
	 * @param ctx the parse tree
	 */
	void exitB(P1_810197633_810197657Parser.BContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#b_}.
	 * @param ctx the parse tree
	 */
	void enterB_(P1_810197633_810197657Parser.B_Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#b_}.
	 * @param ctx the parse tree
	 */
	void exitB_(P1_810197633_810197657Parser.B_Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#b__}.
	 * @param ctx the parse tree
	 */
	void enterB__(P1_810197633_810197657Parser.B__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#b__}.
	 * @param ctx the parse tree
	 */
	void exitB__(P1_810197633_810197657Parser.B__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#b___}.
	 * @param ctx the parse tree
	 */
	void enterB___(P1_810197633_810197657Parser.B___Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#b___}.
	 * @param ctx the parse tree
	 */
	void exitB___(P1_810197633_810197657Parser.B___Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#back}.
	 * @param ctx the parse tree
	 */
	void enterBack(P1_810197633_810197657Parser.BackContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#back}.
	 * @param ctx the parse tree
	 */
	void exitBack(P1_810197633_810197657Parser.BackContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#front}.
	 * @param ctx the parse tree
	 */
	void enterFront(P1_810197633_810197657Parser.FrontContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#front}.
	 * @param ctx the parse tree
	 */
	void exitFront(P1_810197633_810197657Parser.FrontContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#mathTerm}.
	 * @param ctx the parse tree
	 */
	void enterMathTerm(P1_810197633_810197657Parser.MathTermContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#mathTerm}.
	 * @param ctx the parse tree
	 */
	void exitMathTerm(P1_810197633_810197657Parser.MathTermContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#boolTerm}.
	 * @param ctx the parse tree
	 */
	void enterBoolTerm(P1_810197633_810197657Parser.BoolTermContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#boolTerm}.
	 * @param ctx the parse tree
	 */
	void exitBoolTerm(P1_810197633_810197657Parser.BoolTermContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#term}.
	 * @param ctx the parse tree
	 */
	void enterTerm(P1_810197633_810197657Parser.TermContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#term}.
	 * @param ctx the parse tree
	 */
	void exitTerm(P1_810197633_810197657Parser.TermContext ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#return__}.
	 * @param ctx the parse tree
	 */
	void enterReturn__(P1_810197633_810197657Parser.Return__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#return__}.
	 * @param ctx the parse tree
	 */
	void exitReturn__(P1_810197633_810197657Parser.Return__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#continue__}.
	 * @param ctx the parse tree
	 */
	void enterContinue__(P1_810197633_810197657Parser.Continue__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#continue__}.
	 * @param ctx the parse tree
	 */
	void exitContinue__(P1_810197633_810197657Parser.Continue__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#break__}.
	 * @param ctx the parse tree
	 */
	void enterBreak__(P1_810197633_810197657Parser.Break__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#break__}.
	 * @param ctx the parse tree
	 */
	void exitBreak__(P1_810197633_810197657Parser.Break__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#print__}.
	 * @param ctx the parse tree
	 */
	void enterPrint__(P1_810197633_810197657Parser.Print__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#print__}.
	 * @param ctx the parse tree
	 */
	void exitPrint__(P1_810197633_810197657Parser.Print__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#func__}.
	 * @param ctx the parse tree
	 */
	void enterFunc__(P1_810197633_810197657Parser.Func__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#func__}.
	 * @param ctx the parse tree
	 */
	void exitFunc__(P1_810197633_810197657Parser.Func__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#new__}.
	 * @param ctx the parse tree
	 */
	void enterNew__(P1_810197633_810197657Parser.New__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#new__}.
	 * @param ctx the parse tree
	 */
	void exitNew__(P1_810197633_810197657Parser.New__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#class__}.
	 * @param ctx the parse tree
	 */
	void enterClass__(P1_810197633_810197657Parser.Class__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#class__}.
	 * @param ctx the parse tree
	 */
	void exitClass__(P1_810197633_810197657Parser.Class__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#for__}.
	 * @param ctx the parse tree
	 */
	void enterFor__(P1_810197633_810197657Parser.For__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#for__}.
	 * @param ctx the parse tree
	 */
	void exitFor__(P1_810197633_810197657Parser.For__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#foreach__}.
	 * @param ctx the parse tree
	 */
	void enterForeach__(P1_810197633_810197657Parser.Foreach__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#foreach__}.
	 * @param ctx the parse tree
	 */
	void exitForeach__(P1_810197633_810197657Parser.Foreach__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#def__}.
	 * @param ctx the parse tree
	 */
	void enterDef__(P1_810197633_810197657Parser.Def__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#def__}.
	 * @param ctx the parse tree
	 */
	void exitDef__(P1_810197633_810197657Parser.Def__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#else__}.
	 * @param ctx the parse tree
	 */
	void enterElse__(P1_810197633_810197657Parser.Else__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#else__}.
	 * @param ctx the parse tree
	 */
	void exitElse__(P1_810197633_810197657Parser.Else__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#in__}.
	 * @param ctx the parse tree
	 */
	void enterIn__(P1_810197633_810197657Parser.In__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#in__}.
	 * @param ctx the parse tree
	 */
	void exitIn__(P1_810197633_810197657Parser.In__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#list__}.
	 * @param ctx the parse tree
	 */
	void enterList__(P1_810197633_810197657Parser.List__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#list__}.
	 * @param ctx the parse tree
	 */
	void exitList__(P1_810197633_810197657Parser.List__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#if__}.
	 * @param ctx the parse tree
	 */
	void enterIf__(P1_810197633_810197657Parser.If__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#if__}.
	 * @param ctx the parse tree
	 */
	void exitIf__(P1_810197633_810197657Parser.If__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#int__}.
	 * @param ctx the parse tree
	 */
	void enterInt__(P1_810197633_810197657Parser.Int__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#int__}.
	 * @param ctx the parse tree
	 */
	void exitInt__(P1_810197633_810197657Parser.Int__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#string__}.
	 * @param ctx the parse tree
	 */
	void enterString__(P1_810197633_810197657Parser.String__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#string__}.
	 * @param ctx the parse tree
	 */
	void exitString__(P1_810197633_810197657Parser.String__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#void__}.
	 * @param ctx the parse tree
	 */
	void enterVoid__(P1_810197633_810197657Parser.Void__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#void__}.
	 * @param ctx the parse tree
	 */
	void exitVoid__(P1_810197633_810197657Parser.Void__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#bool__}.
	 * @param ctx the parse tree
	 */
	void enterBool__(P1_810197633_810197657Parser.Bool__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#bool__}.
	 * @param ctx the parse tree
	 */
	void exitBool__(P1_810197633_810197657Parser.Bool__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#extends__}.
	 * @param ctx the parse tree
	 */
	void enterExtends__(P1_810197633_810197657Parser.Extends__Context ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#extends__}.
	 * @param ctx the parse tree
	 */
	void exitExtends__(P1_810197633_810197657Parser.Extends__Context ctx);
	/**
	 * Enter a parse tree produced by {@link P1_810197633_810197657Parser#name}.
	 * @param ctx the parse tree
	 */
	void enterName(P1_810197633_810197657Parser.NameContext ctx);
	/**
	 * Exit a parse tree produced by {@link P1_810197633_810197657Parser#name}.
	 * @param ctx the parse tree
	 */
	void exitName(P1_810197633_810197657Parser.NameContext ctx);
}